package com.park.lostark.display;

public class Title {

		public static final String TITLE = "**************************\n" + "   LOSTARK 보유 캐릭터관리\n" + "**************************\n";
}
